executor/executor.o: executor/executor.c executor/../minishell.h \
 executor/.././utils/libft/libft.h
