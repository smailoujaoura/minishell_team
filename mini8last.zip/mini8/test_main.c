#include "minishell.h"

void	swap_contents(t_list *one, t_list *two)
{
	char	*tmp;

	tmp = one->content;
	one->content = two->content;
	two->content = tmp;
}

int	cmp(char *one, char *two)
{
	return (ft_strncmp(one, two, ft_strlen(one)));
}

int	calculate_length(t_list *list)
{
	int		len;
	int		i;
	char	*str;

	len = 0;
	while (list)
	{
		i = 0;
		str = (char *)list->content;
		while (str[i++])
			len++;
		if (list->next)
			len++;
		list = list->next;
	}
	return (len);
}

char	*make_array_list(t_list *list)
{
	char	*result;
	char	*str;
	int		i;
	int		j;

	j = 0;
	result = ft_malloc(calculate_length(list) + 1, ALLOCATE);
	while (list)
	{
		i = 0;
		str = (char *)list->content;
		while (str[i])
			result[j++] = str[i++];
		list = list->next;
	}
	result[j] = '\0';
	return (result);
}

char	*sort_list_make_array(t_list *list)
{
	int		swapped;
	t_list	*ptr;

	swapped = 1;
	ptr = list;
	if (list == NULL)
		return (NULL);
	while (swapped)
	{
		swapped = 0;
		while (ptr->next)
		{
			if (cmp(ptr->content, ptr->next->content) > 0)
			{
				swap_contents(ptr, ptr->next);
				swapped = 1;
			}
			ptr = ptr->next;
		}
		ptr = list;
	}
	return (make_array_list(list));
}

# define IS_WILD 'w'
# define NOT_WILD 'n'

int	match_wildcard(const char *pattern, const char *str, const char *is_wild)
{
	while (*pattern)
	{
		if (*pattern == '*' && *is_wild == IS_WILD)
		{
			while (*pattern == '*' && *is_wild == IS_WILD)
				pattern++, is_wild++;
			if (!*pattern)
				return (1);
			while (*str)
				if (match_wildcard(pattern, str++, is_wild))
					return (1);
			return (0);
		}
		if (*pattern != *str || (*pattern == '*' && *is_wild == NOT_WILD))
			return (0);
		pattern++, str++, is_wild++;
	}
	return (*str == '\0');
}

int main(void)
{
	DIR 			*ptr;
	struct dirent	*entry;
	t_list			*list;

	ptr = opendir(".");
	entry = readdir(ptr);
	list = NULL;
	while (entry)
	{
		if (match_wildcard(".*", entry->d_name, "nw"))
		{
			ft_lstadd_back(&list, ft_lstnew(strdup(entry->d_name)));
		}
		entry = readdir(ptr);
	}
	closedir(ptr);
	t_list *move = list;
	printf("BEFORE: \n");
	while(move)
	{
		printf("%s  ", (char *)move->content);
		move = move->next;
	}
	printf("\n\nSORTED: \n");
	move = list;
	char *str = sort_list_make_array(list);
	while(move)
	{
		printf("%s  ", (char *)move->content);
		move = move->next;
	}
	printf("\n");
	printf("[%s]\n", str);
	return (0);
}
