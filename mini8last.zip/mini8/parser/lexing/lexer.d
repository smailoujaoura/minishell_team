parser/lexing/lexer.o: parser/lexing/lexer.c \
 parser/lexing/../../minishell.h \
 parser/lexing/../.././utils/libft/libft.h
