utils/libft/allocator.o: utils/libft/allocator.c utils/libft/libft.h \
 utils/libft/../../minishell.h utils/libft/../.././utils/libft/libft.h
