executor/expander.o: executor/expander.c executor/../minishell.h \
 executor/.././utils/libft/libft.h
