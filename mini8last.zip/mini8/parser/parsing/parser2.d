parser/parsing/parser2.o: parser/parsing/parser2.c \
 parser/parsing/../../minishell.h \
 parser/parsing/../.././utils/libft/libft.h
