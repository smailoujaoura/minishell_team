parser/lexing/lexer_utils1.o: parser/lexing/lexer_utils1.c \
 parser/lexing/../../minishell.h \
 parser/lexing/../.././utils/libft/libft.h
