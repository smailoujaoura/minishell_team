utils/list_utils.o: utils/list_utils.c utils/../minishell.h \
 utils/.././utils/libft/libft.h
