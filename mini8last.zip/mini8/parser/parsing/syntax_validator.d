parser/parsing/syntax_validator.o: parser/parsing/syntax_validator.c \
 parser/parsing/../../minishell.h \
 parser/parsing/../.././utils/libft/libft.h
