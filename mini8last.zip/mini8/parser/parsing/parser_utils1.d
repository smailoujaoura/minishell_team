parser/parsing/parser_utils1.o: parser/parsing/parser_utils1.c \
 parser/parsing/../../minishell.h \
 parser/parsing/../.././utils/libft/libft.h
