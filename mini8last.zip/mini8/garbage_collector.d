garbage_collector.o: garbage_collector.c minishell.h utils/libft/libft.h
