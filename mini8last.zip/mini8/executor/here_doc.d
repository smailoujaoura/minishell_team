executor/here_doc.o: executor/here_doc.c executor/../minishell.h \
 executor/.././utils/libft/libft.h
