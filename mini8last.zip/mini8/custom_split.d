custom_split.o: custom_split.c utils/libft/libft.h
