#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>

int main()
{
    int pipefd[2];
    char buffer[100];
    int fd;

    pipe(pipefd);

    int saved_stdout = dup(1);

	dup2(pipefd[1], 1);
    printf("This is some test data\n");
    fflush(stdout);

    dup2(saved_stdout, 1);

    fd = open("output.txt", O_WRONLY | O_CREAT | O_APPEND, 0644);

    int bytes_read = read(pipefd[0], buffer, sizeof(buffer));
    write(fd, buffer, bytes_read);
    
    close(fd);
    close(pipefd[0]);
    close(pipefd[1]);
    close(saved_stdout);
    
    printf("Done\n");
    
    return 0;
}