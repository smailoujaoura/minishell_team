env_handler.o: env_handler.c minishell.h utils/libft/libft.h
