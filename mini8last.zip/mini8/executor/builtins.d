executor/builtins.o: executor/builtins.c executor/../minishell.h \
 executor/.././utils/libft/libft.h
