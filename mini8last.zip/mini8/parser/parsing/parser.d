parser/parsing/parser.o: parser/parsing/parser.c \
 parser/parsing/../../minishell.h \
 parser/parsing/../.././utils/libft/libft.h
