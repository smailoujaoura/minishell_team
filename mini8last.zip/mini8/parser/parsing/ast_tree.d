parser/parsing/ast_tree.o: parser/parsing/ast_tree.c \
 parser/parsing/../../minishell.h \
 parser/parsing/../.././utils/libft/libft.h
